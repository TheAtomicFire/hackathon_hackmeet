package com.example.hackathon_hackmeet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class signUpForm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_form);
    }
}