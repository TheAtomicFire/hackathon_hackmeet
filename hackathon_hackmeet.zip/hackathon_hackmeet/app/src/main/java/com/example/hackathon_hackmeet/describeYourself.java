package com.example.hackathon_hackmeet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class describeYourself extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_describe_yourself);
    }
}